-- Este script se ejecuta UNA SOLA VEZ, la primera vez que el
-- contenedor "db" inicializa su volumen (carpeta vacía).
-- La imagen mariadb ya crea la base "wordpress" sola a partir de
-- las variables MYSQL_DATABASE / MYSQL_USER / MYSQL_PASSWORD; este
-- script agrega la segunda base para OwnCloud.
--
-- IMPORTANTE: la clave de abajo debe coincidir EXACTAMENTE con el
-- valor de OC_DB_PASSWORD en tu archivo .env antes del primer
-- "docker compose up".

CREATE DATABASE IF NOT EXISTS owncloud CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
CREATE USER IF NOT EXISTS 'oc_user'@'%' IDENTIFIED BY 'ClaveOwncloud123!';
GRANT ALL PRIVILEGES ON owncloud.* TO 'oc_user'@'%';
FLUSH PRIVILEGES;
